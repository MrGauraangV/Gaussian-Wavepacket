classdef Gaussian_Wavepacket_Raw < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        GridLayout                    matlab.ui.container.GridLayout
        LeftPanel                     matlab.ui.container.Panel
        RightPanel                    matlab.ui.container.Panel
        TabGroup                      matlab.ui.container.TabGroup
        IntroductionTab               matlab.ui.container.Tab
        TextArea                      matlab.ui.control.TextArea
        ForPH311QuantumMechanicsandApplicationsLabel  matlab.ui.control.Label
        GAUSSIANWAVEPACKETLabel       matlab.ui.control.Label
        Hyperlink                     matlab.ui.control.Hyperlink
        TimeEvolutionTab              matlab.ui.container.Tab
        VariationofParametersPanel    matlab.ui.container.Panel
        nmLabel_2                     matlab.ui.control.Label
        nmLabel                       matlab.ui.control.Label
        XEditField_2                  matlab.ui.control.NumericEditField
        GraphButton_2                 matlab.ui.control.Button
        FreezeButton                  matlab.ui.control.StateButton
        Sigma0EditField_2             matlab.ui.control.NumericEditField
        Sigma0EditField_2Label        matlab.ui.control.Label
        AlphaEditField_2              matlab.ui.control.NumericEditField
        AlphaEditField_2Label         matlab.ui.control.Label
        AnimationSpeedEditField       matlab.ui.control.NumericEditField
        AnimationSpeedEditFieldLabel  matlab.ui.control.Label
        XEditField_1                  matlab.ui.control.NumericEditField
        XLabel                        matlab.ui.control.Label
        AlphaEditField                matlab.ui.control.NumericEditField
        AlphaEditFieldLabel           matlab.ui.control.Label
        Sigma0EditField               matlab.ui.control.NumericEditField
        Sigma0EditFieldLabel          matlab.ui.control.Label
        PlotsofWavefunctionandProbabilityDensityPanel  matlab.ui.container.Panel
        UIAxes_4                      matlab.ui.control.UIAxes
        UIAxes_5                      matlab.ui.control.UIAxes
        UIAxes_3                      matlab.ui.control.UIAxes
        UIAxes_2                      matlab.ui.control.UIAxes
        Normalized                    matlab.ui.container.Tab
        NormalisedWavefunctionandProbabilityDensityPanel  matlab.ui.container.Panel
        UIAxes_10                     matlab.ui.control.UIAxes
        GaussianParametersandProbabilityPanel  matlab.ui.container.Panel
        ScaleFactorEditField          matlab.ui.control.NumericEditField
        ScaleFactorEditFieldLabel     matlab.ui.control.Label
        TimeSliderscaledsecondsLabel  matlab.ui.control.Label
        ProbabilityCalculatorLabel    matlab.ui.control.Label
        Momentum0EditField            matlab.ui.control.NumericEditField
        Momentum0EditFieldLabel       matlab.ui.control.Label
        ToEditField                   matlab.ui.control.NumericEditField
        ToEditFieldLabel              matlab.ui.control.Label
        FromEditField                 matlab.ui.control.NumericEditField
        FromEditFieldLabel            matlab.ui.control.Label
        ProbabilityEditField          matlab.ui.control.NumericEditField
        ProbabilityEditFieldLabel     matlab.ui.control.Label
        ComputeButton                 matlab.ui.control.Button
        timeSlider_2                  matlab.ui.control.Slider
        Sigma0EditField_3             matlab.ui.control.NumericEditField
        Sigma0EditField_3Label        matlab.ui.control.Label
        GraphParametersPanel          matlab.ui.container.Panel
        nmLabel_3                     matlab.ui.control.Label
        xEditField_2                  matlab.ui.control.NumericEditField
        xEditField                    matlab.ui.control.NumericEditField
        xLabel                        matlab.ui.control.Label
        GraphButton_4                 matlab.ui.control.Button
        ContextMenu                   matlab.ui.container.ContextMenu
        Menu                          matlab.ui.container.Menu
        Menu2                         matlab.ui.container.Menu
        Menu3                         matlab.ui.container.Menu
    end

    % Properties that correspond to apps with auto-reflow
    properties (Access = private)
        onePanelWidth = 576;
    end

    
    properties (Access = private)
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
             app.Sigma0EditFieldLabel.Interpreter = 'latex';
            app.AlphaEditFieldLabel.Interpreter = 'latex';
             app.Sigma0EditField_2Label.Interpreter = 'latex';
             app.AlphaEditField_2Label.Interpreter = 'latex';

                        title(app.UIAxes_2, "Re[\Psi(X,\tau)]")
                        title(app.UIAxes_3, "|\Psi(X,\tau)|^2")
                        title(app.UIAxes_4, "Re[\Psi(X,\tau)]")
                        title(app.UIAxes_5, "|\Psi(X,\tau)|^2")

                        
           app.Sigma0EditFieldLabel.Text = 'Sigma $(\sigma_0)$:';
            app.AlphaEditFieldLabel.Text = 'Alpha $(\alpha)$:';
             app.Sigma0EditField_2Label.Text = 'Sigma $(\sigma_0)$:';
             app.AlphaEditField_2Label.Text = 'Alpha $(\alpha)$:';
        end

        % Button pushed function: GraphButton_2
        function GraphButton_2Pushed(app, event)
            xmax=app.XEditField_1.Value;
            xmin=app.XEditField_2.Value;

   
            X=linspace(xmin,xmax,2000);
            a1=app.AlphaEditField.Value;
            s01=app.Sigma0EditField.Value .* 10^(-9);

            a2=app.AlphaEditField_2.Value;
            s02=app.Sigma0EditField_2.Value .* 10^(-9);

            t=0.1;
            speed = 1/app.AnimationSpeedEditField.Value/10;
            
            function psi_1=f1(X,t)
                R=cos(atan(t)./2);
                Amp1=(pi.^(.25).*(s01+s01.*t.^2).^(.5));
                Gauss1=exp(-(X-a1.*t).^2./(2.*(1+t.^2)));
                psi_1 = R./Amp1.*Gauss1.*cos((2.*a1.*X+t.*(X.^2-a1.^2))./(2.*(1+t.^2)));
            end

            function mpsi_1=g1(X,t)
                s1=s01.*sqrt(1+t.^2);
                Amp2=1/(sqrt(pi).*s1);
                Gauss2=exp(-(X-a1.*t).^2/(1.*(1+t.^2)));
                mpsi_1=Amp2.*Gauss2;           
            end

            function psi_2=f2(X,t)
                R=cos(atan(t)./2);
                Amp1=(pi.^(.25).*(s02+s02.*t.^2).^(.5));
                Gauss1=exp(-(X-a2.*t).^2./(2.*(1+t.^2)));
                psi_2 = R./Amp1.*Gauss1.*cos((2.*a2.*X+t.*(X.^2-a2.^2))./(2.*(1+t.^2)));
            end
            function mpsi_2=g2(X,t)
                s2=s02.*sqrt(1+t.^2);
                Amp2=1/(sqrt(pi).*s2);
                Gauss2=exp(-(X-a2.*t).^2/(1.*(1+t.^2)));
                mpsi_2=Amp2.*Gauss2;           
            end

            m1=max(f1(X,t));
            m2=max(g1(X,t));
            m3=max(f2(X,t));
            m4=max(g2(X,t));

            cla(app.UIAxes_2,'reset')
            cla(app.UIAxes_3,'reset')
            cla(app.UIAxes_4,'reset')
            cla(app.UIAxes_5,'reset')

            h1=plot(app.UIAxes_2,X,f1(X,t));
            h2=plot(app.UIAxes_3,X,g1(X,t));

            h3=plot(app.UIAxes_4,X,f2(X,t));
            h4=plot(app.UIAxes_5,X,g2(X,t));
       

            axis(app.UIAxes_2,[xmin xmax -m1/2 m1/2]);
            axis(app.UIAxes_3,[xmin xmax 0 m2]);
            axis(app.UIAxes_4,[xmin xmax -m1/2 m1/2]);
            axis(app.UIAxes_5,[xmin xmax 0 m4]);

            set(app.UIAxes_2, 'YTickLabel', {})
            set(app.UIAxes_3, 'YTickLabel', {})
            set(app.UIAxes_4, 'YTickLabel', {})
            set(app.UIAxes_5, 'YTickLabel', {})

            title(app.UIAxes_2, "Re[\Psi(X,\tau)]")
            title(app.UIAxes_3, "|\Psi(X,\tau)|^2")
            title(app.UIAxes_4, "Re[\Psi(X,\tau)]")
            title(app.UIAxes_5, "|\Psi(X,\tau)|^2")

             xlabel(app.UIAxes_2,"X (nm)")
             xlabel(app.UIAxes_3,"X (nm)")
             xlabel(app.UIAxes_4,"X (nm)")
             xlabel(app.UIAxes_5,"X (nm)")

            for t=linspace(0.1,20,200)
                if app.FreezeButton.Value==1
                    pause(100)
                end
                if strcmp(app.TabGroup.SelectedTab.Title, app.TimeEvolutionTab.Title)

                    psi_1=f1(X,t);
                    mpsi_1=g1(X,t);
                    psi_2=f2(X,t);
                    mpsi_2=g2(X,t);
                 
                    set(h1,'YData',psi_1);
                    set(h2,'YData',mpsi_1);
                    set(h3,'YData',psi_2);
                    set(h4,'YData',mpsi_2);

                    pause(speed)
                else 
                    break;
                end
            end
          

        end

        % Callback function: GraphButton_4, timeSlider_2, timeSlider_2
        function GraphButton_4Pushed(app, event)
            cla(app.UIAxes_10,'reset')

            h=1.05e-34;
            s03=app.Sigma0EditField_3.Value*10^(9);

            p0=app.Momentum0EditField.Value;
            m=9.1e-31;
            scalefactor=app.ScaleFactorEditField.Value;

            t=app.timeSlider_2.Value*scalefactor;
            
            xmin=app.xEditField_2.Value;
            xmax=app.xEditField.Value;

            x=linspace(xmin,xmax,200);

            alpha=p0*s03/h;
            tau=h/(m*s03^2)*t;
            X=x./s03;
           
        
            function psi=f(X,t)
                R=cos(atan(tau)./2);
                Amp1=(pi.^(.25).*(s03+s03.*tau.^2).^(.5));
                Gauss1=exp(-(X-alpha.*tau).^2./(2.*(1+tau.^2)));
                psi = R./Amp1.*Gauss1.*cos((2.*alpha.*X+tau.*(X.^2-alpha.^2))./(2.*(1+tau.^2)));
            end

            function psi2=g(X,t)
                s=s03.*sqrt(1+tau.^2); 
                Amp2=1/(sqrt(pi).*s);
                Gauss2=exp(-(X-alpha.*tau).^2/((1+tau.^2)));
                psi2=Amp2.*Gauss2;     
            end

    yyaxis(app.UIAxes_10,'left') 
    plot(app.UIAxes_10,x,f(X,t))
    xlabel(app.UIAxes_10,"x (nm)")
    ylabel(app.UIAxes_10,"\psi")

    yyaxis(app.UIAxes_10,'right')
    plot(app.UIAxes_10,x,g(X,t))
    xlabel(app.UIAxes_10,"x (nm)")
    ylabel(app.UIAxes_10,"\psi^2")
        end

        % Button pushed function: ComputeButton
        function ComputeButtonPushed(app, event)
             h=1.05e-34;
             scalefactor=app.ScaleFactorEditField.Value;

            t=app.timeSlider_2.Value*scalefactor;
             p0=app.Momentum0EditField.Value;
             m=9.1e-31;

 s03=app.Sigma0EditField_3.Value*10^(9);
 alpha=p0*s03/h;
 tau=h/(m*s03^2)*t;

            syms x

            xmin=app.xEditField_2.Value;
            xmax=app.xEditField.Value;

                s=s03.*sqrt(1+tau.^2); 
                Amp2=1/(sqrt(pi).*s);
                Gauss2=exp(-(x./s03-alpha.*tau).^2/((1+tau.^2)));
                psi2=Amp2.*Gauss2; 

F = double(int(psi2,[app.FromEditField.Value app.ToEditField.Value]))

app.ProbabilityEditField.Value=F

xline(app.UIAxes_10,app.FromEditField.Value,'--k')
xline(app.UIAxes_10,app.ToEditField.Value,'--k')
        end

        % Changes arrangement of the app based on UIFigure width
        function updateAppLayout(app, event)
            currentFigureWidth = app.UIFigure.Position(3);
            if(currentFigureWidth <= app.onePanelWidth)
                % Change to a 2x1 grid
                app.GridLayout.RowHeight = {638, 638};
                app.GridLayout.ColumnWidth = {'1x'};
                app.RightPanel.Layout.Row = 2;
                app.RightPanel.Layout.Column = 1;
            else
                % Change to a 1x2 grid
                app.GridLayout.RowHeight = {'1x'};
                app.GridLayout.ColumnWidth = {12, '1x'};
                app.RightPanel.Layout.Row = 1;
                app.RightPanel.Layout.Column = 2;
            end
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Position = [100 100 976 638];
            app.UIFigure.Name = 'MATLAB App';

            % Create GridLayout
            app.GridLayout = uigridlayout(app.UIFigure);
            app.GridLayout.ColumnWidth = {12, '1x'};
            app.GridLayout.RowHeight = {'1x'};
            app.GridLayout.ColumnSpacing = 0;
            app.GridLayout.RowSpacing = 0;
            app.GridLayout.Padding = [0 0 0 0];
            app.GridLayout.Scrollable = 'on';

            % Create LeftPanel
            app.LeftPanel = uipanel(app.GridLayout);
            app.LeftPanel.Layout.Row = 1;
            app.LeftPanel.Layout.Column = 1;

            % Create RightPanel
            app.RightPanel = uipanel(app.GridLayout);
            app.RightPanel.Layout.Row = 1;
            app.RightPanel.Layout.Column = 2;

            % Create TabGroup
            app.TabGroup = uitabgroup(app.RightPanel);
            app.TabGroup.Position = [1 25 959 593];

            % Create IntroductionTab
            app.IntroductionTab = uitab(app.TabGroup);
            app.IntroductionTab.Title = 'Introduction';

            % Create Hyperlink
            app.Hyperlink = uihyperlink(app.IntroductionTab);
            app.Hyperlink.HorizontalAlignment = 'center';
            app.Hyperlink.FontName = 'Comic Sans MS';
            app.Hyperlink.FontSize = 36;
            app.Hyperlink.URL = 'https://www.mathcha.io/editor/m5WPnhOwsvWh8rzW1NFzelqzgCj2Pe14hKJLqzp';
            app.Hyperlink.Position = [119 290 721 109];
            app.Hyperlink.Text = 'Click Here for Manual of GUI';

            % Create GAUSSIANWAVEPACKETLabel
            app.GAUSSIANWAVEPACKETLabel = uilabel(app.IntroductionTab);
            app.GAUSSIANWAVEPACKETLabel.HorizontalAlignment = 'center';
            app.GAUSSIANWAVEPACKETLabel.FontName = 'Comic Sans MS';
            app.GAUSSIANWAVEPACKETLabel.FontSize = 48;
            app.GAUSSIANWAVEPACKETLabel.Position = [167 470 629 66];
            app.GAUSSIANWAVEPACKETLabel.Text = 'GAUSSIAN WAVEPACKET';

            % Create ForPH311QuantumMechanicsandApplicationsLabel
            app.ForPH311QuantumMechanicsandApplicationsLabel = uilabel(app.IntroductionTab);
            app.ForPH311QuantumMechanicsandApplicationsLabel.HorizontalAlignment = 'center';
            app.ForPH311QuantumMechanicsandApplicationsLabel.FontName = 'Comic Sans MS';
            app.ForPH311QuantumMechanicsandApplicationsLabel.FontSize = 18;
            app.ForPH311QuantumMechanicsandApplicationsLabel.FontAngle = 'italic';
            app.ForPH311QuantumMechanicsandApplicationsLabel.Position = [266 435 431 24];
            app.ForPH311QuantumMechanicsandApplicationsLabel.Text = 'For PH311 - Quantum Mechanics and Applications ';

            % Create TextArea
            app.TextArea = uitextarea(app.IntroductionTab);
            app.TextArea.Editable = 'off';
            app.TextArea.HorizontalAlignment = 'center';
            app.TextArea.FontName = 'Comic Sans MS';
            app.TextArea.FontSize = 18;
            app.TextArea.BackgroundColor = [0.9412 0.9412 0.9412];
            app.TextArea.Position = [73 122 803 116];
            app.TextArea.Value = {'This application aims to provide an insight on the time evolution of a Gaussian wavepacket, precisely for a free electron. Variation of certain parameters that govern the shape and time evolution of a gaussian wavepacket, like 𝜎 and 𝛼, the GUI provides an animation for the evolution of the defined wavepacket across an arbitrary range of time values.'};

            % Create TimeEvolutionTab
            app.TimeEvolutionTab = uitab(app.TabGroup);
            app.TimeEvolutionTab.Title = 'Time Evolution';

            % Create PlotsofWavefunctionandProbabilityDensityPanel
            app.PlotsofWavefunctionandProbabilityDensityPanel = uipanel(app.TimeEvolutionTab);
            app.PlotsofWavefunctionandProbabilityDensityPanel.TitlePosition = 'centertop';
            app.PlotsofWavefunctionandProbabilityDensityPanel.Title = 'Plots of Wavefunction and Probability Density';
            app.PlotsofWavefunctionandProbabilityDensityPanel.BackgroundColor = [1 1 1];
            app.PlotsofWavefunctionandProbabilityDensityPanel.Position = [233 -12 726 581];

            % Create UIAxes_2
            app.UIAxes_2 = uiaxes(app.PlotsofWavefunctionandProbabilityDensityPanel);
            xlabel(app.UIAxes_2, 'X')
            ylabel(app.UIAxes_2, 'Y')
            zlabel(app.UIAxes_2, 'Z')
            app.UIAxes_2.YTick = [0 0.2 0.4 0.6 0.8 1];
            app.UIAxes_2.Color = [0.702 0.8392 0.9294];
            app.UIAxes_2.XGrid = 'on';
            app.UIAxes_2.YGrid = 'on';
            app.UIAxes_2.Position = [9 281 349 234];

            % Create UIAxes_3
            app.UIAxes_3 = uiaxes(app.PlotsofWavefunctionandProbabilityDensityPanel);
            xlabel(app.UIAxes_3, 'X')
            ylabel(app.UIAxes_3, 'Y')
            zlabel(app.UIAxes_3, 'Z')
            app.UIAxes_3.BoxStyle = 'full';
            app.UIAxes_3.Color = [0.702 0.8392 0.9294];
            app.UIAxes_3.ClippingStyle = 'rectangle';
            app.UIAxes_3.XGrid = 'on';
            app.UIAxes_3.YGrid = 'on';
            app.UIAxes_3.Position = [7 19 349 234];

            % Create UIAxes_5
            app.UIAxes_5 = uiaxes(app.PlotsofWavefunctionandProbabilityDensityPanel);
            xlabel(app.UIAxes_5, 'X')
            ylabel(app.UIAxes_5, 'Y')
            zlabel(app.UIAxes_5, 'Z')
            app.UIAxes_5.Color = [1 0.6588 0.6588];
            app.UIAxes_5.XGrid = 'on';
            app.UIAxes_5.YGrid = 'on';
            app.UIAxes_5.Position = [366 17 349 234];

            % Create UIAxes_4
            app.UIAxes_4 = uiaxes(app.PlotsofWavefunctionandProbabilityDensityPanel);
            xlabel(app.UIAxes_4, 'X')
            ylabel(app.UIAxes_4, 'Y')
            zlabel(app.UIAxes_4, 'Z')
            app.UIAxes_4.Color = [1 0.6588 0.6588];
            app.UIAxes_4.XGrid = 'on';
            app.UIAxes_4.YGrid = 'on';
            app.UIAxes_4.Position = [367 276 348 240];

            % Create VariationofParametersPanel
            app.VariationofParametersPanel = uipanel(app.TimeEvolutionTab);
            app.VariationofParametersPanel.TitlePosition = 'centertop';
            app.VariationofParametersPanel.Title = 'Variation of Parameters';
            app.VariationofParametersPanel.BackgroundColor = [0.8 0.8 0.8];
            app.VariationofParametersPanel.Position = [0 -9 234 578];

            % Create Sigma0EditFieldLabel
            app.Sigma0EditFieldLabel = uilabel(app.VariationofParametersPanel);
            app.Sigma0EditFieldLabel.BackgroundColor = [0.702 0.8392 0.9294];
            app.Sigma0EditFieldLabel.HorizontalAlignment = 'center';
            app.Sigma0EditFieldLabel.Position = [45 429 82 27];
            app.Sigma0EditFieldLabel.Text = 'Sigma0';

            % Create Sigma0EditField
            app.Sigma0EditField = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.Sigma0EditField.Limits = [0.1 Inf];
            app.Sigma0EditField.HorizontalAlignment = 'center';
            app.Sigma0EditField.BackgroundColor = [0.702 0.8392 0.9294];
            app.Sigma0EditField.Position = [136 430 52 27];
            app.Sigma0EditField.Value = 5;

            % Create AlphaEditFieldLabel
            app.AlphaEditFieldLabel = uilabel(app.VariationofParametersPanel);
            app.AlphaEditFieldLabel.BackgroundColor = [0.702 0.8392 0.9294];
            app.AlphaEditFieldLabel.HorizontalAlignment = 'center';
            app.AlphaEditFieldLabel.Position = [48 477 79 27];
            app.AlphaEditFieldLabel.Text = 'Alpha';

            % Create AlphaEditField
            app.AlphaEditField = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.AlphaEditField.HorizontalAlignment = 'center';
            app.AlphaEditField.BackgroundColor = [0.702 0.8392 0.9294];
            app.AlphaEditField.Position = [134 479 52 27];
            app.AlphaEditField.Value = 5;

            % Create XLabel
            app.XLabel = uilabel(app.VariationofParametersPanel);
            app.XLabel.HorizontalAlignment = 'center';
            app.XLabel.Position = [88 21 33 22];
            app.XLabel.Text = '< X <';

            % Create XEditField_1
            app.XEditField_1 = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.XEditField_1.HorizontalAlignment = 'center';
            app.XEditField_1.Position = [126 16 46 32];
            app.XEditField_1.Value = 70;

            % Create AnimationSpeedEditFieldLabel
            app.AnimationSpeedEditFieldLabel = uilabel(app.VariationofParametersPanel);
            app.AnimationSpeedEditFieldLabel.HorizontalAlignment = 'center';
            app.AnimationSpeedEditFieldLabel.Position = [21 68 97 22];
            app.AnimationSpeedEditFieldLabel.Text = 'Animation Speed';

            % Create AnimationSpeedEditField
            app.AnimationSpeedEditField = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.AnimationSpeedEditField.Limits = [0.1 Inf];
            app.AnimationSpeedEditField.HorizontalAlignment = 'center';
            app.AnimationSpeedEditField.Position = [125 69 47 22];
            app.AnimationSpeedEditField.Value = 1;

            % Create AlphaEditField_2Label
            app.AlphaEditField_2Label = uilabel(app.VariationofParametersPanel);
            app.AlphaEditField_2Label.BackgroundColor = [1 0.6588 0.6588];
            app.AlphaEditField_2Label.HorizontalAlignment = 'center';
            app.AlphaEditField_2Label.Position = [46 376 75 27];
            app.AlphaEditField_2Label.Text = 'Alpha';

            % Create AlphaEditField_2
            app.AlphaEditField_2 = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.AlphaEditField_2.HorizontalAlignment = 'center';
            app.AlphaEditField_2.BackgroundColor = [1 0.6588 0.6588];
            app.AlphaEditField_2.Position = [137 378 52 27];
            app.AlphaEditField_2.Value = 5;

            % Create Sigma0EditField_2Label
            app.Sigma0EditField_2Label = uilabel(app.VariationofParametersPanel);
            app.Sigma0EditField_2Label.BackgroundColor = [1 0.6588 0.6588];
            app.Sigma0EditField_2Label.HorizontalAlignment = 'center';
            app.Sigma0EditField_2Label.Position = [46 330 81 27];
            app.Sigma0EditField_2Label.Text = 'Sigma0';

            % Create Sigma0EditField_2
            app.Sigma0EditField_2 = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.Sigma0EditField_2.Limits = [0.1 Inf];
            app.Sigma0EditField_2.HorizontalAlignment = 'center';
            app.Sigma0EditField_2.BackgroundColor = [1 0.6588 0.6588];
            app.Sigma0EditField_2.Position = [139 332 52 27];
            app.Sigma0EditField_2.Value = 5;

            % Create FreezeButton
            app.FreezeButton = uibutton(app.VariationofParametersPanel, 'state');
            app.FreezeButton.Text = 'Freeze';
            app.FreezeButton.BackgroundColor = [1 1 0];
            app.FreezeButton.Position = [59 115 121 30];

            % Create GraphButton_2
            app.GraphButton_2 = uibutton(app.VariationofParametersPanel, 'push');
            app.GraphButton_2.ButtonPushedFcn = createCallbackFcn(app, @GraphButton_2Pushed, true);
            app.GraphButton_2.Position = [55 164 130 26];
            app.GraphButton_2.Text = 'Graph';

            % Create XEditField_2
            app.XEditField_2 = uieditfield(app.VariationofParametersPanel, 'numeric');
            app.XEditField_2.HorizontalAlignment = 'center';
            app.XEditField_2.Position = [39 16 46 32];

            % Create nmLabel
            app.nmLabel = uilabel(app.VariationofParametersPanel);
            app.nmLabel.Position = [193 432 45 22];
            app.nmLabel.Text = 'nm';

            % Create nmLabel_2
            app.nmLabel_2 = uilabel(app.VariationofParametersPanel);
            app.nmLabel_2.Position = [194 334 45 22];
            app.nmLabel_2.Text = 'nm';

            % Create Normalized
            app.Normalized = uitab(app.TabGroup);
            app.Normalized.Title = 'Normalized Analysis';

            % Create GraphParametersPanel
            app.GraphParametersPanel = uipanel(app.Normalized);
            app.GraphParametersPanel.TitlePosition = 'centertop';
            app.GraphParametersPanel.Title = 'Graph Parameters';
            app.GraphParametersPanel.Position = [7 463 319 100];

            % Create GraphButton_4
            app.GraphButton_4 = uibutton(app.GraphParametersPanel, 'push');
            app.GraphButton_4.ButtonPushedFcn = createCallbackFcn(app, @GraphButton_4Pushed, true);
            app.GraphButton_4.Position = [198 18 84 35];
            app.GraphButton_4.Text = 'Graph';

            % Create xLabel
            app.xLabel = uilabel(app.GraphParametersPanel);
            app.xLabel.HorizontalAlignment = 'center';
            app.xLabel.Position = [73 26 32 22];
            app.xLabel.Text = '< x <';

            % Create xEditField
            app.xEditField = uieditfield(app.GraphParametersPanel, 'numeric');
            app.xEditField.HorizontalAlignment = 'center';
            app.xEditField.Position = [106 21 46 32];
            app.xEditField.Value = 5;

            % Create xEditField_2
            app.xEditField_2 = uieditfield(app.GraphParametersPanel, 'numeric');
            app.xEditField_2.HorizontalAlignment = 'center';
            app.xEditField_2.Position = [22 21 46 32];
            app.xEditField_2.Value = -5;

            % Create nmLabel_3
            app.nmLabel_3 = uilabel(app.GraphParametersPanel);
            app.nmLabel_3.Position = [157 26 45 22];
            app.nmLabel_3.Text = 'nm';

            % Create GaussianParametersandProbabilityPanel
            app.GaussianParametersandProbabilityPanel = uipanel(app.Normalized);
            app.GaussianParametersandProbabilityPanel.TitlePosition = 'centertop';
            app.GaussianParametersandProbabilityPanel.Title = 'Gaussian Parameters and Probability';
            app.GaussianParametersandProbabilityPanel.Position = [7 -1 319 460];

            % Create Sigma0EditField_3Label
            app.Sigma0EditField_3Label = uilabel(app.GaussianParametersandProbabilityPanel);
            app.Sigma0EditField_3Label.HorizontalAlignment = 'right';
            app.Sigma0EditField_3Label.Position = [7 398 46 22];
            app.Sigma0EditField_3Label.Text = 'Sigma0';

            % Create Sigma0EditField_3
            app.Sigma0EditField_3 = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.Sigma0EditField_3.Limits = [1e-10 Inf];
            app.Sigma0EditField_3.Position = [61 396 71 26];
            app.Sigma0EditField_3.Value = 1e-09;

            % Create timeSlider_2
            app.timeSlider_2 = uislider(app.GaussianParametersandProbabilityPanel);
            app.timeSlider_2.Limits = [0 50];
            app.timeSlider_2.ValueChangedFcn = createCallbackFcn(app, @GraphButton_4Pushed, true);
            app.timeSlider_2.ValueChangingFcn = createCallbackFcn(app, @GraphButton_4Pushed, true);
            app.timeSlider_2.Position = [21 334 278 3];
            app.timeSlider_2.Value = 0.1;

            % Create ComputeButton
            app.ComputeButton = uibutton(app.GaussianParametersandProbabilityPanel, 'push');
            app.ComputeButton.ButtonPushedFcn = createCallbackFcn(app, @ComputeButtonPushed, true);
            app.ComputeButton.Position = [115 98 106 39];
            app.ComputeButton.Text = 'Compute';

            % Create ProbabilityEditFieldLabel
            app.ProbabilityEditFieldLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.ProbabilityEditFieldLabel.BackgroundColor = [0.651 0.651 0.651];
            app.ProbabilityEditFieldLabel.HorizontalAlignment = 'center';
            app.ProbabilityEditFieldLabel.FontWeight = 'bold';
            app.ProbabilityEditFieldLabel.Position = [135 61 66 22];
            app.ProbabilityEditFieldLabel.Text = 'Probability';

            % Create ProbabilityEditField
            app.ProbabilityEditField = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.ProbabilityEditField.Editable = 'off';
            app.ProbabilityEditField.HorizontalAlignment = 'center';
            app.ProbabilityEditField.FontWeight = 'bold';
            app.ProbabilityEditField.BackgroundColor = [0.651 0.651 0.651];
            app.ProbabilityEditField.Position = [115 26 106 35];

            % Create FromEditFieldLabel
            app.FromEditFieldLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.FromEditFieldLabel.HorizontalAlignment = 'right';
            app.FromEditFieldLabel.Position = [38 166 33 22];
            app.FromEditFieldLabel.Text = 'From';

            % Create FromEditField
            app.FromEditField = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.FromEditField.Position = [86 157 40 39];
            app.FromEditField.Value = -1;

            % Create ToEditFieldLabel
            app.ToEditFieldLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.ToEditFieldLabel.HorizontalAlignment = 'right';
            app.ToEditFieldLabel.Position = [177 166 25 22];
            app.ToEditFieldLabel.Text = 'To';

            % Create ToEditField
            app.ToEditField = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.ToEditField.Position = [217 157 40 39];
            app.ToEditField.Value = 1;

            % Create Momentum0EditFieldLabel
            app.Momentum0EditFieldLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.Momentum0EditFieldLabel.HorizontalAlignment = 'right';
            app.Momentum0EditFieldLabel.Position = [158 399 73 22];
            app.Momentum0EditFieldLabel.Text = 'Momentum0';

            % Create Momentum0EditField
            app.Momentum0EditField = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.Momentum0EditField.Position = [239 396 71 26];
            app.Momentum0EditField.Value = 9e-26;

            % Create ProbabilityCalculatorLabel
            app.ProbabilityCalculatorLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.ProbabilityCalculatorLabel.Position = [11 218 302 22];
            app.ProbabilityCalculatorLabel.Text = '------------------ Probability Calculator  ------------------';

            % Create TimeSliderscaledsecondsLabel
            app.TimeSliderscaledsecondsLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.TimeSliderscaledsecondsLabel.Position = [94 344 159 22];
            app.TimeSliderscaledsecondsLabel.Text = 'Time Slider (scaled seconds)';

            % Create ScaleFactorEditFieldLabel
            app.ScaleFactorEditFieldLabel = uilabel(app.GaussianParametersandProbabilityPanel);
            app.ScaleFactorEditFieldLabel.HorizontalAlignment = 'right';
            app.ScaleFactorEditFieldLabel.Position = [85 272 73 22];
            app.ScaleFactorEditFieldLabel.Text = 'Scale Factor';

            % Create ScaleFactorEditField
            app.ScaleFactorEditField = uieditfield(app.GaussianParametersandProbabilityPanel, 'numeric');
            app.ScaleFactorEditField.Position = [173 272 57 19];
            app.ScaleFactorEditField.Value = 1e-06;

            % Create NormalisedWavefunctionandProbabilityDensityPanel
            app.NormalisedWavefunctionandProbabilityDensityPanel = uipanel(app.Normalized);
            app.NormalisedWavefunctionandProbabilityDensityPanel.TitlePosition = 'centertop';
            app.NormalisedWavefunctionandProbabilityDensityPanel.Title = 'Normalised Wavefunction and Probability Density ';
            app.NormalisedWavefunctionandProbabilityDensityPanel.Position = [334 1 622 560];

            % Create UIAxes_10
            app.UIAxes_10 = uiaxes(app.NormalisedWavefunctionandProbabilityDensityPanel);
            xlabel(app.UIAxes_10, 'x (nm)')
            zlabel(app.UIAxes_10, 'Z')
            app.UIAxes_10.Position = [28 105 559 406];

            % Create ContextMenu
            app.ContextMenu = uicontextmenu(app.UIFigure);

            % Create Menu
            app.Menu = uimenu(app.ContextMenu);
            app.Menu.Text = 'Menu';

            % Create Menu2
            app.Menu2 = uimenu(app.ContextMenu);
            app.Menu2.Text = 'Menu2';

            % Create Menu3
            app.Menu3 = uimenu(app.ContextMenu);
            app.Menu3.Text = 'Menu3';
            
            % Assign app.ContextMenu
            app.timeSlider_2.ContextMenu = app.ContextMenu;

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = Gaussian_Wavepacket_Raw

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end