function matter_wave_gui()
    % Create the main GUI window
    fig = figure('Name', 'Matter Wave Simulation', ...
                 'NumberTitle', 'off', ...
                 'Position', [100, 100, 800, 600], ...
                 'MenuBar', 'none', ...
                 'Resize', 'off', ...
                 'Color', [0.9, 0.9, 0.95]); % Light blue-gray background

    % Title
    uicontrol('Style', 'text', ...
              'Position', [200, 540, 400, 40], ...
              'String', 'Matter Wave Interaction with Rectangular Barrier', ...
              'FontSize', 16, ...
              'FontWeight', 'bold', ...
              'BackgroundColor', [0.9, 0.9, 0.95]);

    % Input labels and fields
    createLabel(fig, 'Barrier Width (L):', [50, 480, 150, 25]);
    widthInput = createEditBox(fig, [220, 480, 100, 25], '1');

    createLabel(fig, 'Barrier Potential (V0):', [50, 430, 150, 25]);
    potentialInput = createEditBox(fig, [220, 430, 100, 25], '2');

    createLabel(fig, 'Particle Energy (E):', [50, 380, 150, 25]);
    energyInput = createEditBox(fig, [220, 380, 100, 25], '1');

    % Graph button
    uicontrol('Style', 'pushbutton', ...
              'Position', [350, 450, 100, 30], ...
              'String', 'Graph', ...
              'FontSize', 12, ...
              'Callback', @plot_wavefunction);

    % Axes for graph
    ax = axes('Parent', fig, ...
              'Position', [0.1, 0.1, 0.8, 0.5], ...
              'Color', [1, 1, 1]); % White background

    % Callback for plotting the wavefunction
    function plot_wavefunction(~, ~)
        % Get inputs
        L = str2double(get(widthInput, 'String')); % Barrier width
        V0 = str2double(get(potentialInput, 'String')); % Barrier potential
        E = str2double(get(energyInput, 'String')); % Particle energy

        % Input validation
        if isnan(L) || isnan(V0) || isnan(E) || L <= 0 || V0 < 0 || E < 0
            errordlg('Please enter valid positive values for the parameters.', ...
                     'Input Error');
            return;
        end

        % Define constants and regions
        x1 = linspace(-2 * L, 0, 500); % Region I (Left of barrier)
        x2 = linspace(0, L, 500); % Region II (Inside the barrier)
        x3 = linspace(L, 3 * L, 500); % Region III (Right of barrier)

        % Wave vector in different regions
        k1 = sqrt(2 * E); % Region I and III
        if E > V0
            k2 = sqrt(2 * (E - V0)); % Region II (Sinusoidal wave)
        else
            k2 = sqrt(2 * (V0 - E)); % Region II (Exponential decay)
        end

        % Amplitudes based on transmission and reflection coefficients
        R = ((k1 - k2) / (k1 + k2))^2; % Reflection coefficient
        T = 1 - R; % Transmission coefficient
        A = 1; % Incident wave amplitude
        B = sqrt(R) * A; % Reflected wave amplitude
        C = sqrt(T) * A; % Transmitted wave amplitude

        % Wavefunctions
        psi1 = A * exp(1i * k1 * x1) + B * exp(-1i * k1 * x1); % Region I
        if E > V0
            psi2 = A * cos(k2 * x2); % Sinusoidal wave in barrier
        else
            psi2 = A * exp(-k2 * abs(x2)); % Decaying wave in barrier
        end
        psi3 = C * exp(1i * k1 * (x3 - L)); % Region III

        % Normalize for plotting
        max_val = max([max(abs(psi1)), max(abs(psi2)), max(abs(psi3))]);
        psi1 = psi1 / max_val;
        psi2 = psi2 / max_val;
        psi3 = psi3 / max_val;

        % Clear and plot
        cla(ax);
        hold(ax, 'on');

        % Plot wavefunctions
        plot(ax, x1, real(psi1), 'b-', 'LineWidth', 2); % Region I
        plot(ax, x2, real(psi2), 'g-', 'LineWidth', 2); % Region II
        plot(ax, x3, real(psi3), 'r-', 'LineWidth', 2); % Region III

        % Plot barrier
        barrier = [zeros(1, length(x1)), V0 * ones(1, length(x2)), zeros(1, length(x3))];
        x_total = [x1, x2, x3];
        plot(ax, x_total, barrier / max(barrier), 'k--', 'LineWidth', 1.5);

        % Customize plot appearance
        title(ax, sprintf('Matter Wave for E = %.2f, V0 = %.2f, L = %.2f', E, V0, L), ...
              'FontSize', 12);
        xlabel(ax, 'Position (x)', 'FontSize', 12, 'FontWeight', 'bold');
        ylabel(ax, '\psi(x)', 'FontSize', 12, 'FontWeight', 'bold');
        legend(ax, {'Region I', 'Region II', 'Region III', 'Barrier'}, 'Location', 'best');
        grid(ax, 'on');
        hold(ax, 'off');
    end

    % Helper functions
    function createLabel(fig, text, position)
        uicontrol('Style', 'text', ...
                  'Position', position, ...
                  'String', text, ...
                  'HorizontalAlignment', 'right', ...
                  'FontSize', 12, ...
                  'BackgroundColor', get(fig, 'Color'));
    end

    function h = createEditBox(fig, position, default)
        h = uicontrol('Style', 'edit', ...
                      'Position', position, ...
                      'String', default);
    end
end
