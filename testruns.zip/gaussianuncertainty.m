st=1
hc=6.636e-34/(2*pi)
n=1

x=linspace(-10e-9,10e-9,100)
p=linspace(-3e9,3e9,100)

s=[5e-9;1e-9;0.5e-9;1e-10]
A=1./((pi.*s(n).^2).^(.25))
psi = A.^2.*exp(-x.^2 ./ (s(n).^2))


s=[1e-9]
a=s(n)./(sqrt(pi).*hc) .* exp(-s(n).^2 .*p.^2.)

for n=1:st
    subplot(st,2,2*n-1)
    plot(x,psi)
    
   subplot(st,2,2*n)
   plot(p,a)
end
