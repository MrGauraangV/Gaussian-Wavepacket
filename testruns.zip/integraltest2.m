clear all
syms x
s=2
expr=exp(-x^2);

F = double(int(expr,[-inf inf]))

