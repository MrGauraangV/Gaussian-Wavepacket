clc; 
h=1.05e-34;
s0=5e-9;
p0=9e-26;
m=9.1e-31;
t=5e-6;

mode=1

if mode ==1
x=linspace(-1,1,1000);
alpha=p0*s0/h;
tau=h/(m*s0^2)*t;
X=x./s0;

s=s0.*sqrt(1+tau.^2);

Amp2=1/(sqrt(pi).*s);
Gauss2=exp(-(X-alpha.*tau).^2/((1+tau.^2)));
psi2=Amp2.*Gauss2;

plot(x,psi2)

else 
syms x;
alpha=p0*s0/h;
tau=h/(m*s0^2)*t;
X=x./s0;

s=s0.*sqrt(1+tau.^2);

Amp2=1/(sqrt(pi).*s);
Gauss2=exp(-(X-alpha.*tau).^2/((1+tau.^2)));
psi2=Amp2.*Gauss2;

lol=int(psi2,[-inf inf]);
F=vpa(lol)
end